import React from 'react'
import { injectIntl } from 'react-intl'
import { Col, Layout, Row } from 'antd';
import styles from '../Video.scss'
import zh_CN from '../../../i18n/zh_CN'
import bg from '../../../components/backGround.png'
import videojs from 'video.js';
import 'video.js/dist/video-js.min.css';

const { Content } = Layout;

class VideoBox1 extends React.Component {

  constructor(props) {
    super(props)
    let url = window.location.host
    if (url) {
      if (url.indexOf(':') != -1 && window.location.port) {
        url = url.substring(0, url.indexOf(window.location.port) - 1);
      }
    }
    let player1 = 'rtmp://' + url + ':' + '6666' + '/live/room';
    console.log('player1 url', player1)
    this.state = {
      player1: player1,
      width: '100%',
      minHeight: '100%',
      height: '100%',
    }
  }

  componentDidMount() {
    this.player = videojs('video1', {}, function onPlayerReady() {
      this.play();
    })
  }

  componentWillUnmount() {
    if (this.player) {
      this.player.dispose()
    }
  }

  render() {
    const player1 = this.state.player1
    const videoImg = this.props.videoBox1Data.img
    return (
      <Content className={styles.wrapper} style={{ paddingTop: 75, paddingBottom: 15 }}>
        <Row gutter={16}>
          <Col xl={9} lg={24} md={24} sm={24} xs={24}>
            <div className={styles.cardTitle}>
              <div className={styles.cardText}>{zh_CN.ChannelOne}</div>
            </div>
            <div className={styles.cardContent}>
              <video
                style={{ minHeight: this.state.minHeight, height: this.state.height, width: this.state.width }}
                className="video-js"
                id="video1"
                muted
                controls
                autoPlay="autoPlay"
                loop="loop"
                preload="none">
                <source src={player1} type="rtmp/flv" />
              </video>
            </div>
          </Col>
          <Col xl={15} lg={24} md={24} sm={24} xs={24}>
            <div className={styles.cardTitle}>
              <div className={styles.cardText}>{zh_CN.RealTimeFaultData}</div>
            </div>
            <div className={styles.cardContent}>
              <Row gutter={16}>
                <Col span={12}>
                  <table>
                    <thead>
                      <tr>
                        <th>{zh_CN.Attribute}</th>
                        <th>{zh_CN.Result}</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>{zh_CN.cameraID}</td>
                        <td>{this.props.videoBox1Data.info.CameraID}</td>
                      </tr>
                      <tr>
                        <td>{zh_CN.errorType}</td>
                        <td>{this.props.videoBox1Data.info.ErrorType}</td>
                      </tr>
                      <tr>
                        <td>{zh_CN.productionLineID}</td>
                        <td>{this.props.videoBox1Data.info.ProductionLineID}</td>
                      </tr>
                      <tr>
                        <td>{zh_CN.model}</td>
                        <td>{this.props.videoBox1Data.info.Model}</td>
                      </tr>
                      <tr>
                        <td>{zh_CN.location}</td>
                        <td>{this.props.videoBox1Data.info.Location}</td>
                      </tr>
                      <tr>
                        <td>{zh_CN.date}</td>
                        <td>{this.props.videoBox1Data.info.Date}</td>
                      </tr>
                    </tbody>
                  </table>
                </Col>
                <Col span={12} className={styles.imgWap}>
                  <img
                    src={videoImg}
                    onError={(e) => { e.target.onerror = null; e.target.src = bg }}
                  />
                </Col>
              </Row>
            </div>
          </Col>
        </Row>
      </Content>
    )
  }
}

export default injectIntl(VideoBox1)