import axios from 'axios'

function createInstance() {
  // TODO: axios interceptors
  return axios
}

export default createInstance()
