const en_US = {
}

export default en_US;