
In the project directory, you can run:

### `npm install`

### `npm run start`

### `npm run build`

